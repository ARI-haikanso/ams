var execsyncs = require('execsyncs');
    var result = "acting..." + execsyncs('/bin/bash ./activity2.sh');
    console.log(result);
