<?php
echo"Hello world from PHP!";
?>
