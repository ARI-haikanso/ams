//このnodejsスクリプトはswfのdeciderlistに一つのタスクをあげる

var swf = require('./node_modules/aws-swf/index.js');
//var swf = require('../index');
var workflow = new swf.Workflow({
   "domain": "mydomain",
   "workflowType": {
      "name": "myworkflow",
      "version": "1.0"
   },
   "taskList": { "name": "myworkflow-tasklist" },
   "executionStartToCloseTimeout": "1800",
   "taskStartToCloseTimeout": "1800",
   "tagList": ["example"],
   "childPolicy": "TERMINATE"
});


var workflowExecution = workflow.start({ input: "any data ..."}, function (err, runId) {

   if (err) { console.log("Cannot start workflow : ", err); return; }

   console.log("Workflow started, runId: " +runId);

});
