#!/bin/bash

PATH="`dirname $0`:$PATH"
source environment
NOW_DATETIME=$(date +%Y-%m-%d\ %H:%M:%S)
echo $NOW_DATETIME
#df -h
#free -m
#uname -a
/usr/bin/java Hello
php hello.php
mysql -u $USER -p$PASS -h $HOST -P $PORT  $DB -e 'select * from userdata;'
#mysql -u $USER -p$PASS -h $HOST -P $PORT  $DB < test.sql
