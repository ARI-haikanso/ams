var AWS = require('aws-swf').AWS;
AWS.config.loadFromPath('credentials.json');
AWS.config.update({region: 'ap-northeast-1'});

var swf = require('./node_modules/aws-swf/index.js');
var lambda = new AWS.Lambda();

var params = {
    FunctionName: 'activity1',
    InvokeArgs: "{}"
};
 
lambda.invokeAsync(params, function(err, data) {
    if (err) console.log(err, err.stack);
    else     console.log(data);
});
