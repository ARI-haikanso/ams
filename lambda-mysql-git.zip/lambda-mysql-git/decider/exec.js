var execsyncs = require('execsyncs');
    var result = "acting..." + execsyncs('/bin/bash ./activity.sh');
    console.log(result);
