var AWS = require('aws-swf').AWS;
//AWS.config.loadFromPath('credentials.json');
AWS.config.update({region: 'ap-northeast-1'});

var swf = require('./node_modules/aws-swf/index.js');
var lambda = new AWS.Lambda();

var swf = require('./node_modules/aws-swf/index.js');

//the function to delete cloudformation stack
var cloudformation = new AWS.CloudFormation();

function deleteStack(name){
    var params = {
　　　　StackName: name,
      }
    cloudformation.deleteStack(params, function(err, data) {
      if (err)  console.log(err, err.stack);
      else   console.log(data);
    });
}




var myDecider = new swf.Decider({
   "domain": "mydomain",
   "taskList": {"name": "myworkflow-tasklist"},
   "identity": "Decider-01",
   "maximumPageSize": 100,
   "reverseOrder": false // IMPORTANT: must replay events in the right order, ie. from the start
});

//
var stopflag = 0;
myDecider.on('decisionTask', function (decisionTask) {

    //console.log("Got a new decision task !");
    if(!decisionTask.eventList.scheduled('activity1')) {
    
        decisionTask.response.schedule({
            name: 'activity1',
            activity: 'activity1',
        },{ taskList: 'list-activity1' });
        console.log("###decide to do activity1!");
    }

    else if(!decisionTask.eventList.scheduled('activity2')) {
        if(decisionTask.eventList.completed('activity1')) {
         
          decisionTask.response.schedule({
                name: 'activity2',
                activity: 'activity2'
            },{ taskList: 'list-activity2' });
        console.log("###decide to do activity2!");
       }
    }
    else {
          decisionTask.response.stop({
          result: "Decison finished!"
        });
        console.log("###decide to do finish the workflow!");
        stopflag = 1;
    }


    decisionTask.response.respondCompleted(decisionTask.response.decisions, function(err, result) {

      if(err) {
          console.log(err);
          return;
      }

    });
     if ( stopflag == 1 ) {
      console.log("###stoping the decider");
      myDecider.stop();
      deleteStack('batchserver');
   }

});

myDecider.on('poll', function(d) {
    //console.log(_this.config.identity + ": polling for decision tasks...");
    console.log("polling for tasks...");
});

// Start polling
myDecider.start();



/**
 * It is not recommanded to stop the poller in the middle of a long-polling request,
 * because SWF might schedule an DecisionTask to this poller anyway, which will obviously timeout.
 *
 * The .stop() method will wait for the end of the current polling request, 
 * eventually wait for a last decision execution, then stop properly :
 */
process.on('SIGINT', function () {
   console.log('Got SIGINT ! Stopping decider poller after this request...please wait...');
   myDecider.stop();
});

