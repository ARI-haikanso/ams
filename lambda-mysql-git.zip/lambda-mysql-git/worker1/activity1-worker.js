/**
 * This simple worker example will respond to any incoming task
 * on the 'my-workflow-tasklist, by setting the input parameters as the results of the task
 */
//このnodejsスクリプトはSWFのworkerとして、workerlistからactivityをpollする
//
var AWS = require('aws-swf').AWS;
AWS.config.update({region: 'ap-northeast-1'});
var swf = require('./node_modules/aws-swf/index.js');

var activityPoller = new swf.ActivityPoller({
    domain: 'mydomain',
    //taskList: { name: 'my-workflow-tasklist' },
    taskList: { name: 'list-activity1' },
    identity: 'activity1-worker poller ' + process.pid
});

activityPoller.on('activityTask', function(task) {
    console.log("Received new activity task !");
    var output = task.input;
 
    var execsyncs = require('execsyncs');

    var result = "acting..." + execsyncs('/bin/sleep 10s');
    var result = "acting..." + execsyncs('/bin/bash ./activity1.sh');
   //var result = "copying" + execsyncs('cp /var/log/ /tmp/log+`date \"+%Y-%m-%d-%H:%M:%S\"` -rf');
   console.log(result);

    task.respondCompleted(output, function (err) {

        if(err) {
            console.log(err);
            return;
        }
        console.log("activity1-worker responded!");
    });
     activityPoller.stop();
});


activityPoller.on('poll', function(d) {
   // console.log("polling for activity tasks...", d);
    console.log("polling for activity tasks...");
});


// Start polling
activityPoller.start();


/**
 * It is not recommanded to stop the poller in the middle of a long-polling request,
 * because SWF might schedule an ActivityTask to this poller anyway, which will obviously timeout.
 *
 * The .stop() method will wait for the end of the current polling request, 
 * eventually wait for a last activity execution, then stop properly :
 */

//ctl+Cで止める
process.on('SIGINT', function () {
   console.log('Got SIGINT ! Stopping activity poller after this request...please wait...');
   activityPoller.stop();
});
