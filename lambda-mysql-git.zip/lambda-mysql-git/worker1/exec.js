var execsyncs = require('execsyncs');
    var result = "acting..." + execsyncs('/bin/bash ./activity1.sh');
    console.log(result);
