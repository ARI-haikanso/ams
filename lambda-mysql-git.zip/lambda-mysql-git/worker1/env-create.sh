#!/bin/bash

#nodejsの実行環境を作成するスクリプト

yum -y install gcc-c++ git
git clone https://github.com/creationix/nvm.git ~/.nvm
source ~/.nvm/nvm.sh
nvm install 4.3.0
nvm use v4.3.0

#/root/.nvm/versions/node/v4.3.0/bin/　の下にnode,nvmコマンドが存在
