#!/bin/bash

PATH="`/bin/pwd`:$PATH"
source environment
NOW_DATETIME=$(date +%Y-%m-%d\ %H:%M:%S)
echo $NOW_DATETIME
#df -h
#free -m
#uname -a
#/usr/bin/java Hello
#php hello.php
echo "insert "activity1" at $NOW_DATETIME"
mysql -u $USER -p$PASS -h $HOST -P $PORT  $DB -e "insert into userdata(name,time) values(\"activity1\",\"$NOW_DATETIME\");"
#mysql -u $USER -p$PASS -h $HOST -P $PORT  $DB -e 'insert into userdata(name,time) values("activity1","$NOW_DATETIME");'
#mysql -u $USER -p$PASS -h $HOST -P $PORT  $DB < test.sql
