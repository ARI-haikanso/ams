//このnodejsはSWF実行する前に一回実行して、SWFのdomain、workflowType,activitiesをAWSに登録しておく
//dmain:ams-domian
//workflowType:log-lifecycle-workflow
//activity:ebs-attach,log-collect,log-compress,log-upload,ebs-terminate

var AWS = require('aws-swf').AWS;
AWS.config.update({region: 'ap-northeast-1'});

var awsswf = require('./node_modules/aws-swf/index.js'),
    swf = awsswf.createClient();

/**
 *  *  * Register the domain "ams-domain"
 *   *   */
swf.registerDomain({
    name: "mydomain",
    description: "this is a domain for immplementing ams activityies",
    workflowExecutionRetentionPeriodInDays: "1"
}, function (err, results) {

    if (err && err.code != 'DomainAlreadyExistsFault') {
        console.log("Unable to register domain: ", err);
        return;
    }
    else if (!err) {
        console.log("'mydomain' registered !")
    }
    else {
        console.log("'mydomain' already exits!");
    }


    /**
 *  *      * Register the WorkflowType "simple-workflow"
 *   *           */
    swf.registerWorkflowType({
        domain: "mydomain",
        name: "myworkflow",
        version: "1.0"
    }, function (err, results) {

        if (err && err.code != 'TypeAlreadyExistsFault') {
            console.log("Unable to register workflow: ", err);
            return;
        }
        else if (!err) {
                      console.log("'myworkflow' registered !")
                  }
        else {
             console.log("'myworkflow' already exists!")
        }
        /**
 *  *          * Register the ActivityType "log-collect""log-compress"""
 *   *                   */
        swf.registerActivityType({
            domain: "mydomain",
            name: "activity1",
            defaultTaskList: {
                 name: 'list-activity1' /* required */
             },
            version: "1.0"
        }, function (err, results) {

            if (err && err.code != 'TypeAlreadyExistsFault') {
                console.log("Unable to register activity type: ", err);
                return;
            }
            else if (!err) {
                console.log("'activity1' registered !");
           }
            else {
                console.log("'activity1' already exists!");
           }
        });

        swf.registerActivityType({
            domain: "mydomain",
            name: "activity2",
            defaultTaskList: {
                 name: 'list-activity2' /* required */
             },
            version: "1.0"
        }, function (err, results) {

            if (err && err.code != 'TypeAlreadyExistsFault') {
                console.log("Unable to register activity type: ", err);
                return;
            }
            else if (!err) {
                console.log("'activity2' registered !");
           }
            else {
                console.log("'activity2' already exists!");
           }
        });
  


    });

});
